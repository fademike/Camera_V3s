#!/bin/sh

export RED='\033[0;31m'
export GREEN='\033[0;32m'
export BLUE='\033[0;34m'
export NC='\033[0m'

export SSH_SRV='richard@192.168.123.11'
export SSH_DIR='~/outbu'
export SSH_PORT='2222'

